const mysql = require('mysql');
const CONNECTION = {
    debug: false,
    host: "localhost",
    user: "client",
    password: "",
    database: "judges",
    supportBigNumbers: true,
    multipleStatements: true,
    dateStrings: true
};

function query(keys,values,table) {
    return new Promise((resolve, reject) => {
        const connection = mysql.createConnection(CONNECTION);
        let query = mysql.format('INSERT INTO ' + table + ' (??) VALUES (?);', [keys, values]);

        connection.connect();

        connection.query(query, function (err, results) {
            if (err) {
                throw err;
            } else {
                console.log(results);
                resolve(results.insertId);
            }
        });
        connection.end();
    })
}


exports.query = query;