const query = require('./query.js');

it('should add smth to mysql database', function(){
    var expectedResult = 2609;
    query.query(['surname','firstName','patronymic'],['Лазарев','Игорь','Сергеевич'],'judges').then((res)=> {
        if (res !== expectedResult) {
            throw new Error(`Expected ${expectedResult}, but got ${res}`);
        }
    })
});

